import React, { useContext } from "react";
import {
  Autocomplete,
  Button,
  Card,
  Container,
  Divider,
  Grid,
  Paper,
  TextField,
  Toolbar,
  Typography,
} from "@mui/material";
import NotificationsIcon from "@mui/icons-material/Notifications";
import "../navbar/navbar.css";
import logo from "../../../src/assets/Assiduus_Global_Logo.jpeg";
import LineChart from "../../pages/Linechart/Linechart";
import BarChart from "../../pages/Barchart/barchart";

const Navbar = () => {
  const data = [10, 20, 22, 25, 15, 30, 25, 35, 45, 40];
  return (
    <>
      <div className="dashboard">
        <div className="top-nav" variant="outlined">
          <img alt="" className="title-img" src={logo} />
          <input className="search-input" />
        </div>
        <div className="sidebar">
          <div
            class="col-12"
            style={{ display: "flex", justifyContent: "flex-start" }}
          >
            <div class="col-2" style={{ marginLeft: "45px" }}>
              <Toolbar>
                <div class="row">
                  <Typography>Dashboard</Typography>
                  <br />
                  <Typography>Accounts</Typography>
                  <br />
                  <Typography>Payroll</Typography>
                  <br />
                  <Typography>Reports</Typography>
                  <br />
                  <Typography>Advisor</Typography>
                  <br />
                  <Typography>Contacts</Typography>
                </div>
              </Toolbar>
            </div>
            <div
              class="col-10"
              style={{
                marginLeft: "65px",
                background: "grey",
              }}
            >
              <Container maxWidth="xl" sx={{ mt: 6, mb: 6 }}>
                <div
                  class="row"
                  style={{
                    display: "flex",
                    justifyContent: "space-evenly",
                    direction: "row",
                  }}
                >
                  <div class="col-1"></div>
                  <div class="col-4">
                    <Grid item xs={8} md={7} lg={7}>
                      <Paper
                        sx={{
                          p: 1,
                          display: "flex",
                          flexDirection: "Row",
                          height: 280,
                          width: 520,
                        }}
                      >
                        <LineChart data={data} />
                      </Paper>
                    </Grid>
                  </div>
                  <div class="col-1"></div>
                  <div class="col-4" style={{ marginLeft: "100px" }}>
                    <Grid item xs={8} md={7} lg={7}>
                      <Paper
                        sx={{
                          p: 1,
                          display: "flex",
                          flexDirection: "Row",
                          height: 280,
                          width: 520,
                        }}
                      >
                        <BarChart />
                      </Paper>
                    </Grid>
                  </div>
                </div>
              </Container>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Navbar;
