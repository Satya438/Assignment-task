import logo from "./logo.svg";
import "./App.css";
import Navbar from "./components/navbar/navbar";
import Dashboard from "./pages/TOTAL/TOTAL.JS";

function App() {
  return (
    <div className="App">
      <Navbar />
      {/* <Dashboard /> */}
    </div>
  );
}

export default App;
